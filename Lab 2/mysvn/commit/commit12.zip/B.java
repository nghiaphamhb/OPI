class B {
  int t30;
  int t22;
  int t10;
  int t29;
  int t21;
  long t5;
  long t23;
  long t36;
  int[] t33 = {1, -3, 3, -3};
  int[] t28 = {-3, -1, -1, -1};
  int[] t14 = {0, -2, 3, 3, 0};
  static int t15;
  static int t38;
  static int t35;
  static int t32;
  static int t40;
  public B() {
    t30 = 6;
    t22 = 8;
    t10 = 7;
    t29 = 1;
    t21 = 0;
    t5 = 0L;
    t23 = 0L;
    t36 = 0L;
  }
  public void t4() {
    System.out.println("метод t4 в классе B");
    System.out.println(t22 >> 1);
  }
  public void t27() {
    System.out.println("метод t27 в классе B");
    System.out.println(t35++);
  }
  public void t3() {
    System.out.println("метод t3 в классе B");
    System.out.println(--t40);
  }
  public void t9() {
    System.out.println("метод t9 в классе B");
    System.out.println(t32--);
  }
  public void t39() {
    System.out.println("метод t39 в классе B");
    System.out.println(t22);
  }
  public void t16() {
    System.out.println("метод t16 в классе B");
    System.out.println(t30 - 5);
  }
  public static void t11() {
    System.out.println("метод t11 в классе B");
    System.out.println(t32);
  }
  public static void t24() {
    System.out.println("метод t24 в классе B");
    System.out.println((t32 - 4));
  }
  public static void t37() {
    System.out.println("метод t37 в классе B");
    System.out.println(t40);
  }
  public static void t8() {
    System.out.println("метод t8 в классе B");
    System.out.println((t40 - 2));
  }
  public void t26(B r) {
    r.t4();
  }
  public void t26(E r) {
    r.t27();
  }
}
