class E extends B {
  public E() {
    t30 = 9;
    t29 = 1;
    t36 = 6L;
  }
  public void t27() {
    System.out.println("метод t27 в классе E");
    System.out.println(t21++);
  }
  public void t39() {
    System.out.println("метод t39 в классе E");
    System.out.println(t10 >> 2);
  }
  public void t16() {
    System.out.println("метод t16 в классе E");
    System.out.println(t10);
  }
  public static void t11() {
    System.out.println("метод t11 в классе E");
    System.out.println((t15 - 2));
  }
  public static void t24() {
    System.out.println("метод t24 в классе E");
    System.out.println(t15++);
  }
  public static void t37() {
    System.out.println("метод t37 в классе E");
    System.out.println(t38);
  }
  public static void t8() {
    System.out.println("метод t8 в классе E");
    System.out.println((t38 + 5));
  }
  public void t26(B r) {
    r.t3();
  }
  public void t26(E r) {
    r.t9();
  }
}
