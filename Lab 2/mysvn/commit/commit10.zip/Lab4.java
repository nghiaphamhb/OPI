// var. 220541
public class Lab4 {
  public static void main(String[] args) {
  B a = new B();
  B b = new E();
  E c = new E();
  c.t4();
  c.t27();
  b.t3();
  c.t9();
  c.t39();
  c.t16();
  c.t11();
  a.t24();
  a.t37();
  b.t8();
  a.t26(a);
  b.t26(b);
  c.t26(c);
  }
}
previous : 1
